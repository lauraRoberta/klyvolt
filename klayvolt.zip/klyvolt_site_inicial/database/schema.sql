CREATE TABLE empresas (
    id_empresa SERIAL PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE equipamentos (
    id_equipamento SERIAL PRIMARY KEY,
    id_empresa INT REFERENCES empresas(id_empresa),
    nome VARCHAR(120) NOT NULL,
    setor VARCHAR(100),
    consumo_estimado_kwh NUMERIC(10,2)
);

CREATE TABLE consumos (
    id_consumo SERIAL PRIMARY KEY,
    id_equipamento INT REFERENCES equipamentos(id_equipamento),
    consumo_kwh NUMERIC(10,2) NOT NULL,
    data_registro DATE NOT NULL
);

CREATE TABLE metas (
    id_meta SERIAL PRIMARY KEY,
    id_empresa INT REFERENCES empresas(id_empresa),
    meta_mensal_kwh NUMERIC(10,2) NOT NULL,
    mes_referencia VARCHAR(20) NOT NULL
);
