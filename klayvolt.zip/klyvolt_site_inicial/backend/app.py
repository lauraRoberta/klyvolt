from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="Klyvolt API",
    description="API inicial da plataforma de gestão inteligente de energia.",
    version="0.1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def home():
    return {
        "projeto": "Klyvolt",
        "status": "API funcionando",
        "descricao": "Gestão inteligente de energia para pequenas empresas."
    }

@app.get("/consumo")
def listar_consumo():
    return [
        {"equipamento": "Ar-condicionado", "consumo_kwh": 42.5, "status": "alto"},
        {"equipamento": "Iluminação", "consumo_kwh": 18.2, "status": "normal"},
        {"equipamento": "Computadores", "consumo_kwh": 25.8, "status": "atenção"}
    ]

@app.get("/metas")
def metas():
    return {
        "meta_mensal_kwh": 300,
        "consumo_atual_kwh": 214,
        "porcentagem_usada": 71
    }
