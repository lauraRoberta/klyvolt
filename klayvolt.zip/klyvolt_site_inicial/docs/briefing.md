# Briefing da Klyvolt

## Descrição curta
A Klyvolt é uma plataforma de gestão inteligente de energia para pequenas empresas.

## Problema
Pequenas empresas costumam desperdiçar energia porque não acompanham o consumo de forma clara.

## Solução
Um sistema web que registra, organiza e mostra dados de consumo em dashboard.

## Páginas iniciais
- Home
- Dashboard
- Cadastros
- Sobre
- Login

## Funções futuras
- Cadastro de empresas
- Cadastro de equipamentos
- Registro de consumo
- Metas mensais
- Relatórios
- Gráficos estatísticos
- Alertas de consumo alto
