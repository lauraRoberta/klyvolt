const apiUrl = "http://127.0.0.1:8000";
console.log("Klyvolt frontend iniciado.");

async function testarApi() {
  try {
    const resposta = await fetch(`${apiUrl}/`);
    const dados = await resposta.json();
    console.log("Resposta da API:", dados);
  } catch (erro) {
    console.log("API ainda não conectada ou backend desligado.");
  }
}

testarApi();
