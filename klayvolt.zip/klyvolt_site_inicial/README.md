# Klyvolt

Plataforma de controle e gestão inteligente do consumo de energia em pequenas empresas.

A Klyvolt ajuda empresas a registrar consumo, visualizar dados em dashboard, acompanhar metas e identificar desperdícios de energia.

## Estrutura

```text
klyvolt_site_inicial/
├── backend/
│   ├── app.py
│   ├── requirements.txt
│   └── app/
│       ├── routes/
│       ├── models/
│       └── schemas/
├── frontend/
│   ├── pages/
│   │   ├── index.html
│   │   ├── dashboard.html
│   │   ├── cadastros.html
│   │   ├── sobre.html
│   │   └── login.html
│   ├── css/base.css
│   ├── js/main.js
│   └── assets/
├── database/schema.sql
└── docs/briefing.md
```

## Paleta oficial

- #0E1726 — azul-marinho premium
- #4B5B6B — cinza tecnológico
- #16C7B7 — turquesa principal
- #D9E2EC — cinza claro
- #F7F9FC — branco gelo

## Como abrir

Abra `frontend/pages/index.html` no navegador.

## Como rodar a API

```bash
cd backend
pip install -r requirements.txt
uvicorn app:app --reload
```
